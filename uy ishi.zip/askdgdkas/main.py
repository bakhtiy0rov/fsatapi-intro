from fastapi import FastAPI
from auth import auth_router
from models import model_router

app = FastAPI()
app.include_router(auth_router)
app.include_router(model_router)

@app.get("/")
async def intro():
    return {
        'massage': 'Hello'
    }

@app.get("/test")
async def test():
    return {
        'massage': 'test page'
    }

@app.get("/test2")
async def test_2():
    return {
        'massage': 'test2 page'
    }