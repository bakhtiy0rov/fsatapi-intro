from fastapi import APIRouter

model_router = APIRouter(prefix = "/models")


@model_router.get("/")
async def model():
    return {
        'massage': 'auth page'
    }

@model_router.get("/login")
async def model_1():
    return {
        'massage': 'model_1 page'
    }

@model_router.get("/register")
async def model_2():
    return {
        'massage': 'model_2 page'
    }


@model_router.get("/logout")
async def model_3():
    return {
        'massage': 'model_3 page'
    }