from fastapi import APIRouter

auth_router = APIRouter(prefix = "/auth")


@auth_router.get("/")
async def auth_1():
    return {
        'massage': 'auth page'
    }

@auth_router.get("/login")
async def login():
    return {
        'massage': 'login page'
    }

@auth_router.get("/register")
async def register():
    return {
        'massage': 'register page'
    }


@auth_router.get("/logout")
async def logout():
    return {
        'massage': 'logout page'
    }